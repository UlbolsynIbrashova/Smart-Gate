#!c:/Users/gaira/AppData/Local/Programs/Python/Python39/python
print("QWErty")